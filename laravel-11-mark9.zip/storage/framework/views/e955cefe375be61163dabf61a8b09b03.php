<?php $__env->startSection('konten'); ?>
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <div class="container mt-5">
        <div class="d-flex justify-content-end">
            <a href="<?php echo e(route('apel')); ?>" class="btn btn-info">
                <i class="fas fa-home"></i> | Apel Blok Hunian
            </a>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            

                        </head>
                        <h1>Blok <?php echo e($filter); ?></h1>

                            <div id="data-count" class="mb-3"></div>
                            <form action="<?php echo e(route('apels.store')); ?>" method="POST">
                                <input type="hidden" name="rupam" value="<?php echo e(Auth::user()->rupam); ?>">
                                <input type="hidden" name="filter" value="<?php echo e($filter); ?>">
                                <input type="hidden" name="pelanggaran_id" value="1">
                            <?php echo csrf_field(); ?>
                            <div style="overflow-x:auto;">
                                <table
                                        id="example"
                                        class="table table-striped table-bordered dt-responsive nowrap"
                                        cellspacing="0"
                                        width="100%"
                                    >
                                    <thead>
                                        <tr>
                                            <th scope="col">NAMA</th>
                                              <th scope="col">KAMAR</th>
                                            <th scope="col">SELECT</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($row['nama']); ?></td>
                                                <td><?php echo e($row['lokasi']); ?></td>
                                                <td><input type="checkbox" name="selected_data[]" value="<?php echo e($row['nama']); ?>"></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <button type="submit" class="btn btn-danger w-100">Tambah</button>
                            </form>
                            </div>

                            <div class="btn-container mt-3 d-flex justify-content-between">
                                <?php
                                $filter = $filter;
                                $parts = explode('.', $filter);
                                $newFilterLeft = $parts[0] . '.' . ($parts[1] - 1);
                                ?>
                                <a href="<?php echo e(route('kamar', ['filter' => $newFilterLeft])); ?>" class="btn btn-primary btn-left"> < <?php echo e($newFilterLeft); ?></a>

                                <?php
                                $newFilterRight = $parts[0] . '.' . ($parts[1] + 1);
                                ?>
                                <a href="<?php echo e(route('kamar', ['filter' => $newFilterRight])); ?>" class="btn btn-primary"><?php echo e($newFilterRight); ?> ></a>
                            </div>


                        <!-- Include Bootstrap JS and dependencies -->
                        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
                        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
                        
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                var rowCount = document.querySelectorAll('tbody tr').length;
                                document.getElementById('data-count').innerText = 'Jumlah ' + rowCount + ' Orang';
                            });
                        </script>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-11\resources\views\apels\kamar.blade.php ENDPATH**/ ?>