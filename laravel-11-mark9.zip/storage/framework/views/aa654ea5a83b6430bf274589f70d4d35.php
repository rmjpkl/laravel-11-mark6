<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add New users - SantriKoding.com</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background: lightgray">

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <h3>Tambah Data User</h3>
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>


                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Nama</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name', $user->name)); ?>"placeholder="Masukkan Nama">

                                <!-- error message untuk name -->
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Username</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username', $user->username)); ?>" placeholder="Masukkan NIP">

                                <!-- error message untuk username -->
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Password</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" value="<?php echo e(old('password')); ?>" placeholder="Masukkan Password">

                                <!-- error message untuk password -->
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Rupam</label><br>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="rupam" value="rupam 1" id="rupam1" <?php echo e(old('rupam', $user->rupam ) == 'rupam 1' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="rupam1">Rupam 1</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="rupam" value="rupam 2" id="rupam2" <?php echo e(old('rupam', $user->rupam) == 'rupam 2' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="rupam2">Rupam 2</label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="rupam" value="rupam 3" id="rupam3" <?php echo e(old('rupam', $user->rupam) == 'rupam 3' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="rupam3">Rupam 3</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="rupam" value="rupam 4" id="rupam4" <?php echo e(old('rupam', $user->rupam) == 'rupam 4' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="rupam4">Rupam 4</label>
                                        </div>
                                    </div>
                                </div>

                                <!-- error message untuk rupam -->
                                <?php $__errorArgs = ['rupam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="form-group mb-3">
                                <label class="font-weight-bold">Jabatan</label>
                                <select class="form-control <?php $__errorArgs = ['jabatan', $user->jabatan];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jabatan">
                                    <option value="">Pilih Jabatan</option>
                                    <option value="Ka.KPLP" <?php echo e(old('jabatan', $user->jabatan) == 'Ka.KPLP' ? 'selected' : ''); ?>>Ka.KPLP</option>
                                    <option value="Staf KPLP" <?php echo e(old('jabatan', $user->jabatan) == 'Staf KPLP' ? 'selected' : ''); ?>>Staf KPLP</option>
                                    <option value="Ka.Rupam" <?php echo e(old('jabatan', $user->jabatan) == 'Ka.Rupam' ? 'selected' : ''); ?>>Ka.Rupam</option>
                                    <option value="Waka.Rupam" <?php echo e(old('jabatan', $user->jabatan) == 'Waka.Rupam' ? 'selected' : ''); ?>>Waka.Rupam</option>
                                    <option value="P2U" <?php echo e(old('jabatan', $user->jabatan) == 'P2U' ? 'selected' : ''); ?>>P2U</option>
                                    <option value="Anggota Jaga" <?php echo e(old('jabatan', $user->jabatan) == 'Anggota Jaga' ? 'selected' : ''); ?>>Anggota Jaga</option>
                                    <option value="Ka.Lapas" <?php echo e(old('jabatan', $user->jabatan) == 'Ka.Lapas' ? 'selected' : ''); ?>>Ka.Lapas</option>
                                    <option value="lainnya" <?php echo e(old('jabatan', $user->jabatan) == 'lainnya' ? 'selected' : ''); ?>>Lainnya</option>
                                </select>

                                <!-- error message untuk jabatan -->
                                <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mt-2">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="form-group mb-3">
                                <label class="font-weight-bold" for="is_admin">Is Admin:</label>
                                <input type="checkbox" id="is_admin" name="is_admin" value="1" <?php echo e(old('is_admin', $user->is_admin) ? 'checked' : ''); ?>>
                            </div>

                            <button type="submit" class="btn btn-md btn-primary me-3">SAVE</button>
                            <button type="reset" class="btn btn-md btn-warning">RESET</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.ckeditor.com/4.13.1/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'description' );
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-11\resources\views\users\edit.blade.php ENDPATH**/ ?>