<?php $__env->startSection('konten'); ?>
    <div class="container mt-5">
        <div>
            <h2 class="text-center my-5">Tabel Data WBP</h2>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            

                           <?php echo $__env->make('cdntable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </head>

                            <div style="overflow-x:auto;">
                                <table
                                        id="example"
                                        class="table table-striped table-bordered dt-responsive nowrap"
                                        cellspacing="0"
                                        width="100%"
                                    >
                                    <a href="<?php echo e(route('datawbps.create')); ?>" class="btn btn-md btn-success mb-5 btn-block">UPLOAD DATA WBP</a>
                                    <thead class="table-dark">
                                        <tr>
                                            <th scope="col">NAMA</th>
                                            <th scope="col">LOKASI</th>
                                            <th scope="col">T/N</th>
                                            <th scope="col">TANGGAL MASUK</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">crated_at</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $datawbps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datawbp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($datawbp->nama); ?></td>
                                                <td><?php echo e($datawbp->lokasi); ?></td>
                                                <td><?php echo e($datawbp->tn); ?></td>
                                                <td><?php echo e($datawbp->tanggal_masuk); ?></td>
                                                <td><?php echo e($datawbp->status); ?></td>
                                                <td><?php echo e($datawbp->created_at); ?></td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="alert alert-danger">
                                                Data trollings belum Tersedia.
                                            </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <script>
                                $(document).ready(function () {
                                  new DataTable("#example", {
                                    responsive: true,
                                    rowReorder: {
                                      selector: "td:nth-child(2)",
                                    },
                                    // order: [[2, "desc"]],
                                    order: [[1, "asc"]],
                                    dom: "Blfrtip", // Add 'l' to include the length change control
                                    buttons: ["copy", "csv", "excel", "pdf", "print", "colvis"],
                                  });
                                });
                              </script>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        //message with sweetalert
        <?php if(session('success')): ?>
            Swal.fire({
                icon: "success",
                title: "BERHASIL",
                text: "<?php echo e(session('success')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php elseif(session('error')): ?>
            Swal.fire({
                icon: "error",
                title: "GAGAL!",
                text: "<?php echo e(session('error')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php endif; ?>

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-11\resources\views\datawbps\index.blade.php ENDPATH**/ ?>