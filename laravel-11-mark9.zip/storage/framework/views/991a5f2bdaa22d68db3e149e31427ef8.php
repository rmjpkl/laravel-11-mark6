<?php $__env->startSection('konten'); ?>
<main> 
    <div class="container-fluid px-4">
        <div class="card border-0 shadow-sm rounded mt-4">
        <div class="card-body">
        <h3 class="mt-3">Upload Update Database WBP</h3>
        <div class="form-group mb-3">
            <label class="font-weight-bold mb-3" for="nama">Nama:</label>
        <form action="<?php echo e(route('datawbps.import')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" class="form-control mb-3" name="file" required>
            <button type="submit" class="btn btn-md btn-primary me-3">Upload CSV</button>
        </form>
        </div>
        
    </div>
    </div>
    </div>
</main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-11\resources\views\datawbps\import.blade.php ENDPATH**/ ?>