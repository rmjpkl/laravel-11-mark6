<?php $__env->startSection('konten'); ?>
    <div class="container mt-5">
        <div>
            <h2 class="text-center my-5">Tabel Trolling</h2>
            <hr>

        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            <title>Responsive Table with Search and Sort</title>



                            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

                               <!-- DataTables CSS -->
                                <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

                                <!-- jQuery -->
                                <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.5.1.js"></script>

                                <!-- DataTables JS -->
                                <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>

                                <!-- SheetJS -->
                                <script src="https://cdn.sheetjs.com/xlsx-0.19.3/package/dist/xlsx.full.min.js"></script>

                                <script>
                                    $(document).ready(function() {
                                        // Inisialisasi DataTables
                                        $('.table').DataTable();

                                        // Fungsi untuk ekspor ke Excel
                                        $('#export-button').click(function() {
                                            var table = document.querySelector('.table');
                                            var wb = XLSX.utils.table_to_book(table, {sheet: "Sheet1"});
                                            XLSX.writeFile(wb, 'TabelData.xlsx');
                                        });
                                    });
                                </script>




                        </head>

                            <div style="overflow-x:auto;">
                                <table class="table table-bordered" style="width: 100%;">
                                        <button id="export-button" class="btn btn-md btn-primary mb-5 " style="margin-bottom: 10px;">
                                        <i class="fas fa-file-excel"></i> Export Excel <!-- FontAwesome icon with label -->
                                    </button>

                                    <thead class="table-dark">
                                        <tr>
                                            <th scope="col">NAMA</th>
                                            <th scope="col">POINT</th>
                                            <th scope="col">TANGGAL</th>
                                            <th scope="col">RUPAM</th>
                                            <th scope="col" style="width: 20%">ACTIONS</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($point->nama); ?></td>
                                                <td><?php echo e($point->point); ?></td>
                                                <td><?php echo e($point->tanggal); ?></td>
                                                <td><?php echo e($point->rupam); ?></td>
                                                <td class="text-center">
                                                    <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('points.destroy', $point->id)); ?>" method="POST">
                                                        <a href="<?php echo e(route('points.show', $point->id)); ?>" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-eye"></i> <!-- FontAwesome icon for 'show' -->
                                                        </a>
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if(Auth::check() && Auth::user()->is_admin == 1): ?>
                                                        <button type="submit" class="btn btn-sm btn-danger">
                                                            <i class="fas fa-trash-alt"></i> <!-- FontAwesome icon for 'delete' -->
                                                        </button>
                                                        <?php endif; ?>
                                                    </form>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="alert alert-danger">
                                                Data points belum Tersedia.
                                            </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <script>
                                $(document).ready(function() {
                                    $('.table').DataTable();
                                });
                            </script>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        //message with sweetalert
        <?php if(session('success')): ?>
            Swal.fire({
                icon: "success",
                title: "BERHASIL",
                text: "<?php echo e(session('success')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php elseif(session('error')): ?>
            Swal.fire({
                icon: "error",
                title: "GAGAL!",
                text: "<?php echo e(session('error')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php endif; ?>

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-11\resources\views\point\home.blade.php ENDPATH**/ ?>