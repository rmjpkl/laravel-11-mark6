<?php $__env->startSection('konten'); ?>
    <div class="container-fluid">
        <div>
            <h2 class="text-center my-5">Tabel Trolling</h2>
        </div>
                <div class="card border-0 shadow-sm rounded">
                    <div class="card-body">
                        <head>
                            <meta charset="UTF-8">
                            <meta name="viewport" content="width=device-width, initial-scale=1.0">
                            
                           <?php echo $__env->make('cdntable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </head>

                            <div style="overflow-x:auto;">
                                <table
                                        id="example"
                                        class="table table-striped table-bordered dt-responsive nowrap"
                                        cellspacing="0"
                                        width="100%"
                                    >
                                    <a href="<?php echo e(route('trollings.create')); ?>" class="btn btn-md btn-success mb-5 btn-block"><i class="fa fa-map-marker"></i>
                                        ADD LAPORAN</a>
                                        <thead class="table-dark">
                                        <tr>
                                            <th scope="col">NAMA LOKASI</th>
                                            <th scope="col">TANGGAL</th>
                                            <th scope="col">JAM</th>
                                            <th scope="col">RUPAM</th>
                                            <th scope="col">PETUGAS</th>
                                            
                                            <th scope="col" style="width: 20%">ACTIONS</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $trollings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trolling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($trolling->nama_lokasi); ?></td>
                                                <td><?php echo e($trolling->tanggal); ?></td>
                                                <td><?php echo e($trolling->jam); ?></td>
                                                <td><?php echo e($trolling->rupam); ?></td>
                                                <td><?php echo e($trolling->petugas); ?></td>
                                                
                                                <td class="text-center">
                                                    <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('trollings.destroy', $trolling->id)); ?>" method="POST">
                                                        <a href="<?php echo e(route('trollings.show', $trolling->id)); ?>" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-eye"></i> <!-- FontAwesome icon for 'show' -->
                                                        </a>
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php if(Auth::check() && Auth::user()->is_admin == 1): ?>
                                                        <button type="submit" class="btn btn-sm btn-danger">
                                                            <i class="fas fa-trash-alt"></i> <!-- FontAwesome icon for 'delete' -->
                                                        </button>
                                                        <?php endif; ?>
                                                    </form>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="alert alert-danger">
                                                Data trollings belum Tersedia.
                                            </div>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <script>
                                $(document).ready(function () {
                                  new DataTable("#example", {
                                    responsive: true,
                                    rowReorder: {
                                      selector: "td:nth-child(2)",
                                    },
                                    // order: [[2, "desc"]],
                                    // order: [[2, "asc"]],
                                    dom: "Blfrtip", // Add 'l' to include the length change control
                                    buttons: ["copy", "csv", "excel", "pdf", "print", "colvis"],
                                  });
                                });
                              </script>

                        
                    </div>
                </div>
            </div>

    

    <script>
        //message with sweetalert
        <?php if(session('success')): ?>
            Swal.fire({
                icon: "success",
                title: "BERHASIL",
                text: "<?php echo e(session('success')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php elseif(session('error')): ?>
            Swal.fire({
                icon: "error",
                title: "GAGAL!",
                text: "<?php echo e(session('error')); ?>",
                showConfirmButton: false,
                timer: 2000
            });
        <?php endif; ?>

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-11\resources\views/trolling/index.blade.php ENDPATH**/ ?>